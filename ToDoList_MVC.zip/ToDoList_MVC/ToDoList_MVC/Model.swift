//
//  Model.swift
//  ToDoList_MVC
//
//  Created by Татьяна Биркле on 26.03.2024.
//

import Foundation
import UIKit


class Item {
    var string: String
    var completed: Bool
    
    init(string: String, completed: Bool) {
        self.string = string
        self.completed = completed
    }
}

class Model {
    
    var tasksItems: [Item] = []
    var doneTask: Bool = false
    var editButtonClicked: Bool = false
    
    
//    func sortByTitle() {
//        tasksItems.sort {
//            sortedAscending ? $0.string < $1.string : $0.string > $1.string
//        }
//    }
    
    func addTask(taskName: String, isCompleted: Bool = false) {
        tasksItems.append(Item(string: taskName, completed: isCompleted))
    }

    func removeTask(at index: Int) {
        tasksItems.remove(at: index)
    }
    
    func doneTask(at index: Int) -> Bool {
        tasksItems[index].completed = !tasksItems[index].completed
    return tasksItems[index].completed
       
    }
}
