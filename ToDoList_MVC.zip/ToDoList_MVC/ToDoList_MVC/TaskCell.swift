//
//  TaskCell.swift
//  ToDoList_MVC
//
//  Created by Татьяна Биркле on 26.03.2024.
//

import UIKit

protocol TaskCellDelegate {
    func editCell(cell: TaskCell)
    func removeCell(cell: TaskCell)
    func doneCell(cell: TaskCell)
}

class TaskCell: UITableViewCell {
    
    var delegate: TaskCellDelegate?
    
    
    @IBOutlet weak var taskLabelText: UILabel!
    @IBOutlet weak var editButton: UIButton!
    @IBOutlet weak var removeButton: UIButton!
    @IBOutlet weak var doneButton: UIButton!
    
    
    
    @IBAction func editButtonPressed(_ sender: Any) {
        delegate?.editCell(cell: self)
    
    }
    
    @IBAction func removeButtonPressed(_ sender: Any) {
        delegate?.removeCell(cell: self)
    }
    
    @IBAction func doneButtonPressed(_ sender: Any) {
        delegate?.doneCell(cell: self)
    }
}
