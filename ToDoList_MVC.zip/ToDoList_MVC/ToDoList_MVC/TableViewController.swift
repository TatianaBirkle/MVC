//
//  TableViewController.swift
//  ToDoList_MVC
//
//  Created by Татьяна Биркле on 26.03.2024.
//

import UIKit
import Foundation

protocol SaveUserTaskDelegate: AnyObject {
    func saveTask(task: Item)
}
protocol EditUserTaskDelegete: AnyObject {
    func editTask(task: Item)
}

class TableViewController: UITableViewController{
    
    @IBOutlet weak var labelText: UILabel!
    @IBOutlet weak var sortingTasksButton: UIButton!
    @IBOutlet weak var addTaskButton: UIButton!
    
    
    let model = Model()
    var alert = UIAlertController()
    var vc = EnterTaskViewController()
    var editTaskVC = EditTaskViewController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        labelText.text = "Tasks"
        labelText.font = .systemFont(ofSize: 20)
        labelText.textColor = .darkGray
        labelText.shadowColor = .lightGray
        labelText.textAlignment = .center
        
        
        //        model.sortByTitle()
        //        tableView.reloadData()
        
    }
   
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return model.tasksItems.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! TaskCell
        
        cell.delegate = self
        
        let currentItem = model.tasksItems[indexPath.row]
        cell.taskLabelText?.text = currentItem.string
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        if model.doneTask(at: indexPath.row) == true {
            tableView.cellForRow(at: indexPath)?.accessoryType = .checkmark
        } else {
            tableView.cellForRow(at: indexPath)?.accessoryType = .none
        }
    }
    
    @IBAction func addButtonTaskPressed(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
            vc = storyboard.instantiateViewController(withIdentifier: "EnterTaskViewController") as! EnterTaskViewController
            vc.saveTaskDelegate = self
            present(vc, animated: true, completion: nil)
    }
}

extension TableViewController: TaskCellDelegate {
    func editCell(cell: TaskCell) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let currentText = cell.taskLabelText.text
        editTaskVC = storyboard.instantiateViewController(withIdentifier: "EditTaskViewController") as! EditTaskViewController
            editTaskVC.editTaskDelegate = self
            present(editTaskVC, animated: true, completion: nil)
        editTaskVC.editTaskTextField.text = currentText
        
    }
    
    func doneCell(cell: TaskCell) {
        let indexPath = tableView.indexPath(for: cell)
        
        guard let unwrIndexPath = indexPath else {
            return
        }
        cell.doneButton.setBackgroundImage(UIImage(named: "greenV"), for: .normal)
        tableView.reloadData()
    }
    
    func removeCell(cell: TaskCell) {
        let indexPath = tableView.indexPath(for: cell)
        
        guard let unwrIndexPath = indexPath else {
            return
        }
        model.removeTask(at: unwrIndexPath.row)
        tableView.reloadData()
    }
    
}
extension TableViewController: SaveUserTaskDelegate {
    func saveTask(task: Item) {
        
        model.tasksItems.append(task)
        tableView.reloadData()
    }
}
extension TableViewController: EditUserTaskDelegete {
    func editTask(task: Item){
        
        tableView.reloadData()
    }
    
    
}
