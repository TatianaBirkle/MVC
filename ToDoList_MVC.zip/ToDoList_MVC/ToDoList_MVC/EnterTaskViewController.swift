//
//  EnterTaskViewController.swift
//  ToDoList_MVC
//
//  Created by Татьяна Биркле on 26.03.2024.
//

import UIKit

class EnterTaskViewController: UIViewController {

   
    @IBOutlet weak var textField: UITextField!
    weak var saveTaskDelegate: SaveUserTaskDelegate?
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    
    @IBAction func SaveNewTask(_ sender: Any) {
        if let task = textField.text {
                 if !task.isEmpty {
                     let task = Item(string: task, completed: true)
                   saveTaskDelegate?.saveTask(task: task)
                   dismiss(animated: true, completion: nil)
                 }
               }
    }
    
    

}
