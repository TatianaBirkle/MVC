//
//  EditTaskViewController.swift
//  ToDoList_MVC
//
//  Created by Татьяна Биркле on 27.03.2024.
//

import UIKit

class EditTaskViewController: UIViewController {
    
    @IBOutlet weak var editTaskTextField: UITextField!
    
    weak var editTaskDelegate: EditUserTaskDelegete?

    override func viewDidLoad() {
        super.viewDidLoad()
       
    }
    
    @IBAction func saveEditTask(_ sender: Any) {
        if let task = editTaskTextField.text {
            if !task.isEmpty {
                let task = Item(string: task, completed: true)
                editTaskDelegate?.editTask(task: task)
                dismiss(animated: true, completion: nil)
            }
        }
    }
    
}
